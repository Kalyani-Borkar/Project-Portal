<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pace Coaching Center</title>
    <link type="text/css" rel="stylesheet" href="n_welcome.css"/>
  </head>
<body class="custom-background">
<?php
?>
  <div id="header">
  Welcome to Pace Coaching Classes
  </div>
      <div id="center">
      <br>
      <br>
          <ul>
              <li><a href="n_admin_login.htm"><input type=button class="round_button" id="A" value="Administrator" ></a></li>
              <li><a href="n_faculty_login.htm"><input type=button class="round_button"id="F" value="Faculty" ></a></li>
              <li><a href="n_student_login.htm"><input type=button class="round_button" id="S" value="Student" ></a></li>
          </ul>
          <br><br><br><br><br><br><br><br><br>
      </div>
</body>
</html>