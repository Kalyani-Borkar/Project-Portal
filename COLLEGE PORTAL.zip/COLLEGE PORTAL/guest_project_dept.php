<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style>
 <?php include('layout/header_new.php'); ?>  
<div class="wrap" style="padding-bottom:200px;">
					<!---start-content---->
					<div class="content" style="">
						<div class="services">
							<h5>Department</h5>
							<div class="section group" style="vertical-align:middle;padding-top:50px;">
											
								 <table id="t01">
						  <tr>
							<th>Sr. No</th>
							<th>Department Name</th>		
						  </tr>
						   <?php
									
									
 									
										$query = "Select * from branch ";

										$res = mysql_query($query);

										while($row= mysql_fetch_array($res))

										{
											
									 ?>
						  <tr>
							<td><?php echo $row['id'];?></td>
							<td><a href="guest_project_list.php?br=<?php echo $row['branch'];?>"><?php echo $row['branch'];?></a></td>		
							
						  </tr>
						 <?php }?>
						</table>
							</div>
							
							
							
							<div class="clear"></div>
						</div>
						 </div>
					<!---End-content---->
					<div class="clear"> </div>
				</div>
<?php include('layout/footer_new.php'); ?>  
</body>
</html>