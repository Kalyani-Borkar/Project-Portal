<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Flat Login Form</title>
    
    
    <link rel="stylesheet" href="loginstyle/css/reset.css">

    <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

        <link rel="stylesheet" href="loginstyle/css/style.css">

    
<style>
.registercss{background: #f2f2f2 none repeat scroll 0 0;
    border: 0 none;
    border-radius: 3px;
    box-sizing: border-box;
    font-size: 14px;
    margin: 0 0 15px;
    outline: 0 none;
    padding: 15px;
    width: 100%;}
</style>    
    
  </head>

  <body>

    
<div class="container">
  <div class="info">
    
  </div>
</div>
<div class="form">
  <div class="thumbnail"><img src="images/lllogo.png"/></div>
  <div name="register1">
  
  </div>
  <div>
  <form class="login-form" method="post" action="process_register.php">
    <input type="text" placeholder="First Name" name="fname" required pattern="[A-Za-z]*"/>
	<input type="text" placeholder="Last Name" name="lname" required pattern="[A-Za-z]*" />
    <input type="email" placeholder="email address" name="email" required pattern="/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/" />
	 <input type="text" placeholder="Phone Number" name="phone" required pattern="[0-9]*"/>
    <input type="password" placeholder="password" name="password" required/>
   <select class="registercss" name="type">
    <option value="0">Select</option>
   <option value="Staff">Staff</option>
   			<option value="In Student"> In Student</option>
			<option value="Final Year Student">Final Year Student</option>
			<option value="Guest Student">Guest Student</option></select>
	 <input type="text" placeholder="Student/Employee ID" name="seid" required pattern"[A-Za-z]*[0-9]*"/>
    <button name="create">create</button>
    <p class="message">Already registered? <a href="login.php">Sign In</a></p>
  </form>
 
  </div>
</div>
<video id="video" autoplay="autoplay" loop="loop" poster="polina.jpg">
  <source src="http://andytran.me/A%20peaceful%20nature%20timelapse%20video.mp4" type="video/mp4"/>
</video>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="loginstyle/js/index.js"></script>

    
    
    
  </body>
</html>
