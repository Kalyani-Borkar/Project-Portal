<?php
include('layout/config.php');
error_reporting(0);
 ?>
<!DOCTYPE html>
<html>
<head>
<title>Arts School a Educational Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<!--fonts-->
   <?php include('layout/header.php'); ?>   
<!-- banner-slider -->
<!--//end-teachers-->
<!-- //team -->
<!-- gallery -->
<!-- //gallery -->
<!-- contact -->
<div class="contact" id="contact">
  <div class="container">
    <h3 class="tittle two">Upload Project</h3>
    <div class="contact-top">
      <div class="col-md-12 contact-top-right">
        <form method="post" action="process_upload.php" enctype="multipart/form-data">
          <input type="text" class="text" placeholder="Group Name" name="group_name" >
          <br>
          <input type="text" class="text" placeholder="Project Name" name="project_name" >
          <br> 
          <input type="text" class="text" placeholder="Project Guide" name="project_guid" >
          <br>
          <input type="text" class="text" placeholder="Member 1" name="member1" >
          <br>
          <input type="text" class="text" placeholder="Member 2" name="member2" >
          <br>
          <input type="text" class="text" placeholder="Member 3 " name="member3" >
          <br>
		  <input type="text" class="text" placeholder="Member 4 " name="member4" >
          <br>
		  <input type="text" class="text" placeholder="Member 5 " name="member5" >
          <br>
		  <input type="text" class="text" placeholder="Member 6 " name="member6" >
          <br>
         <select name="field">
            <option value="COMPUTER ENGINEERING">COMPUTER ENGINEERING </option>
            <option value="MECHANICAL ENGINEERING">MECHANICAL ENGINEERING </option>
            <option value="ELECTRONICS ENGINEERING">ELECTRONICS ENGINEERING </option>
			 <option value="ELECTRONICS AND COMMUNICATION  ENGINEERING">ELECTRONICS AND COMMUNICATION  ENGINEERING</option>
          </select>
          <select name="year">
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
          </select>
          <br><br>
          <input type="file" class="text" name="file" >
          Upload Synopsis
          <div class="sub-button">
            <input type="submit" value="Submit" name="submit">
          </div>
        </form>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div>
</div>
<!-- //contact -->
<div class="copy-right">
  <div class="container">
    <?php include('layout/footer.php'); ?>
  </div>
</div>
<!-- smooth scrolling -->
<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body></html>
