<?php
include('layout/config.php');

if (isset($_POST["submit"])) {
$iid=$_POST['id'];
$staff_id=$_POST['staff_id'];
$emailid=$_POST['email'];
				//$query='delete from tbl_register where id="'.$iid.'" and type="staff"';
             //UPDATE table_name SET column1=value, column2=value2,...  WHERE some_column=some_value 
$query=" UPDATE tbl_register SET clg_id='".$staff_id."'WHERE id='".$iid."' ";
	
	
	//echo $query;
			if(mysql_query($query))
			{		
					echo " <script> alert('Sucessfully Updated')</script>";
					header("location:user_register_count_new.php");
				
				}
			
			else
			{
				echo mysql_error();}
				
				
}
$to = $emailid;
   $subject = "This is subject";
   echo "<br>Your Mail Id is: ".$to;
   echo "<br> Your Employee Id is: ";
   $message = $staff_id;
   echo $message;
   $header = "bharti.25murkute@gmail.com";
   $retval = mail ($to,$subject,$message,$header);
   if( $retval == true )  
  {
    echo "<br>Message sent successfully...";
  }
  else
  {
     echo "<br>Message could not be sent...";
  }
?>