<?php

require_once('layout/config.php');

 if (isset($_POST["submit"])) {
				

		$username = $_POST['email'];
        $password = $_POST['oldpwd'];
        $newpassword = $_POST['newpwd'];
       
        $result = mysql_query("SELECT password FROM tbl_register WHERE email='".$username."'");
        if(!$result)
        {
        echo "The username you entered does not exist";
        }
        else if($password!= mysql_result($result, 0))
        {
        echo "You entered an incorrect password";
        }
        if(isset($newpassword))
		{
        $sql=mysql_query("UPDATE tbl_register SET password='".$newpassword."' where email='".$username."'");
        if($sql)
        {
      		 echo '<script type="text/javascript"> window.alert("Congratulations You have successfully changed your password")</script>';
			echo '<script type="text/javascript"> window.location="index.php"</script>';
        }
       else
        {
       echo "Passwords do not match";
       }
		}        	
}


?>