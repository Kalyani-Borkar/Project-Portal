<?php

require_once('layout/config.php');

 if (isset($_POST["submit"])) {
				$group_name=$_POST['group_name'];
				$project_name=$_POST['project_name'];
				$field=$_POST['field'];
				$year=$_POST['year'];
				$project_guid=$_POST['project_guid'];
				$member1=$_POST['member1'];
				$member2=$_POST['member2'];
				$member3=$_POST['member3'];
				$member4=$_POST['member4'];
				$member5=$_POST['member5'];
				$member6=$_POST['member6'];
				$member7=$_POST['member7'];
				$domain_name=$_POST['domain_name'];
				$dat=date('Y-m-d');

		$src = $_FILES['file']['tmp_name'];

		$dest = 'file/'.$_FILES['file']['name'];

		$upload = '';

		if(copy($src,$dest))

		//$upload = $_FILES['file']['name'];
$upload=$dest;
         if($sql = "SELECT * FROM register WHERE id=".$_SESSION['id'])
		 {
  //echo $sql;
  $result = mysql_query($sql);
  //while($row = mysql_fetch_array($result,MYSQL_ASSOC))
  //{ 
  
  
if(mysql_query('insert into project set project_name="'.$project_name.'",group_name="'.$group_name.'",filed="'.$field.'",year="'.$year.'",
				project_guid="'.$project_guid.'",project_member1="'.$member1.'",
				project_member2="'.$member2.'",project_member3="'.$member3.'",
				project_member4="'.$member4.'",project_member5="'.$member5.'",
				project_member6="'.$member6.'",project_member7="'.$member7.'",
				synopsis="'.$upload.'",domain_name="'.$domain_name.'",created="'.$dat.'"'))
		{
			
			header("Location: DepartmentList.php");

			

			}

		else
		{
			echo "Couldnot add Project";
			
		}
			
		 }
		
}


?>