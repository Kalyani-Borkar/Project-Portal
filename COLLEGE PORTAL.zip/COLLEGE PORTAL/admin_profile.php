<?php
include('layout/config.php');
error_reporting(0);
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
lable{font-weight:bold;padding-bottom:60px;}
</style></head>
    <?php include('layout/header.php'); ?>   
<!-- banner-slider -->


<!-- about -->
	<div class="about" id="about">
		<div class="container">
			<h3>My Profile</h3>
			<div class="about-grids" style="padding-bottom:20%">
				
				<div class="col-md-8 about-grid-left">
				  <?php
	
										$query = "Select * from tbl_register where id='".$_SESSION['id']."'";
										$res = mysql_query($query);
										
										if($row= mysql_fetch_array($res))
										{										
									 ?>
				<div class="row">
				<div class="col-md-4">
				<lable>Name:</label>
				</div>
				<div class="col-md-4">
				<lable><?php echo $row['f_name']."  ".$row['l_name'];?></label>
				</div>
				</div><br>
				<div class="row">
				<div class="col-md-4">
				<lable>User Id:</label>
				</div>
				<div class="col-md-4">
				<lable><?php echo $row['clg_id'];?></label>
				</div>
				</div><br>
				<div class="row">
				<div class="col-md-4">
				<lable>Email ID/ Username:</label>
				</div>
				<div class="col-md-4">
				<lable><?php echo $row['email'];?></label>
				</div>
				</div><br>
				<div class="row">
				<div class="col-md-4">
				<lable>Phone:</label>
				</div>
				<div class="col-md-4">
				<lable><?php echo $row['phone'];?></label>
				</div>
				</div>
					<?php }?>  
					
					<br><br>
					<div class=""> <a href="changepassword.php"><b><u>Change Password </b></u></a></div>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //about -->
<!-- services -->


	

<!-- //contact -->
<div id="footer-container">
    <?php include('layout/footer.php'); ?>
</div>
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body>
</html>