<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style>
<style>
.displayDiv { display:inline-block; vertical-align:top; overflow:hidden; border:solid grey 1px; }
 .displayDiv select { padding:10px; margin:-5px -20px -5px -5px; }
</style>
<script type="text/javascript">
function ajaxFunction(str)
{
var httpxml;
try
  {
  // Firefox, Opera 8.0+, Safari
  httpxml=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    httpxml=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    try
      {
      httpxml=new ActiveXObject("Microsoft.XMLHTTP");
      }
    catch (e)
      {
      alert("Your browser does not support AJAX!");
      return false;
      }
    }
  }
function stateChanged() 
    {
    if(httpxml.readyState==4)
      {
document.getElementById("displayDiv").innerHTML=httpxml.responseText;
document.getElementById("msg").style.display='none';

      }
    }
	var url="ajax-search-demock.php";
url=url+"?txt="+str;
url=url+"&sid="+Math.random();
httpxml.onreadystatechange=stateChanged;
httpxml.open("GET",url,true);
httpxml.send(null);
document.getElementById("msg").innerHTML="Please Wait ...";
document.getElementById("msg").style.display='inline';

  }
</script>
</head>


 <?php include('layout/header_new.php'); ?> 
<div class="wrap" >

					<!---start-content---->
					<div class="content" >
						<div class="services">
						
         <!--  <div id=msg style="position:absolute; width:400px; height:25px; 
z-index:1; left: 400px; top: 0px; 
border: 1px none #000000"></div>

<form name="myForm">
<input type="text"
onkeyup="ajaxFunction(this.value);" name="username" /> Type letter by letter slowly to read the records displayed.  ( Example type b then i )
 
<div id="displayDiv"></div>

</form>


<div id=mylinks style="position:absolute;  z-index:1; left: 400px; top: 400px;" >Return to <a href=ajax-search.php>Source and tutorial on Keyword search script</a> | <a href=ajax.php>Ajax</a> </div>-->
          
							<h5>Project List</h5>
							<div class="section group">
											
								<table id="t01">
						  <tr>
							<th>Sr. No</th>
							<th>Department Name</th>	
							<th>Project Name</th>
							<th>Domain Name</th>	
							<th>Group Name</th>
							<th>Action</th>	
						  </tr>
						   <?php
	
										 $branch=$_GET['br'];
										$query = "Select * from project where filed='".$branch."' ";
										$res = mysql_query($query);
										$cnt=1;
										while($row= mysql_fetch_array($res))
										{										
									 ?>
						  <tr>
							<td><?php echo $cnt++;	?></td>
							<td><?php echo $row['filed'];?></td>	
							<td><?php echo $row['project_name'];?></td>	
							<td><?php echo $row['domain_name'];?></td>		
							<td><a href="projectDetails_new.php?group=<?php echo $row['group_name'];?>"><?php echo $row['group_name'];?></a></td>	
							<!--<td><?php echo $row['synopsis'];?></td>	-->
							<td><a href="delete_admin.php?id=<?php echo $row['id'];?>">Delete</a><br>
							<a href="download.php?file=<?php echo $row['synopsis'];?>">Download</a>
							</td>	
							
						  </tr>
						 <?php }?>
						</table>
							</div>
							
							
							
							<div class="clear"></div>
						</div>
						 </div>
					<!---End-content---->
					<div class="clear" style="padding-top:250px;"> </div>
				</div>
<?php include('layout/footer_new.php'); ?> 
</body>
</html>