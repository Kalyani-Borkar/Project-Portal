<?php
include('layout/config.php');
error_reporting(0);
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style>
<script src="http://code.jquery.com/jquery-latest.min.js"
        type="text/javascript"></script>
		<script>
jQuery(document).ready(function() {
	function count($this){
		var current = parseInt($this.html(), 10);
		current = current + 1; /* Where 1 is increment */

		$this.html(++current);
		if(current > $this.data('count')){
			$this.html($this.data('count'));
		} else {
			setTimeout(function(){count($this)}, 50);
		}
	}

	jQuery(".stat-count").each(function() {
	  jQuery(this).data('count', parseInt(jQuery(this).html(), 10));
	  jQuery(this).html('0');
	  count(jQuery(this));
	});
});
</script>
</head>
    <?php include('layout/headerAdmin.php'); ?>   
<!-- banner-slider -->


<!-- about -->
	<div class="about" id="about">
		<div class="container">
			<h3>Online User Counter</h3>
			<div class="about-grids" style="padding-bottom:30%">
				
				<div class="col-md-6 about-grid-left">
		<center><h1>			  
    <span class="stat-count">100</span>
    <p class="" style="color:#000000">Online Users</p></h1></center>
</div>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //about -->
<!-- services -->


	

<!-- //contact -->
<div id="footer-container">
    <?php include('layout/footer.php'); ?>
</div>
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body>
</html>