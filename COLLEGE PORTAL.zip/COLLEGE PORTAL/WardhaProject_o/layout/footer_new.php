<style>
.f_grid {
      margin: 0% 0 1% 3.333% !important;
    width: 24.333% !important;
}
.f_logo {
    display: block;
    float: right;
    margin: -4% 0 1% 3.333% !important;
    width: 24.333% !important;
}
</style>
<div class="footer-bg">
<div class="wrap">
<div class="footer">
		<div class="f_grid">
		<div class="social">
				<ul class="follow_icon">
					<li><a href="#" style="opacity: 1;"><img src="style/images/fb.png" alt=""></a></li>
					<li><a href="#" style="opacity: 1;"><img src="style/images/g+.png" alt=""></a></li>
					<li><a href="#" style="opacity: 1;"><img src="style/images/tw.png" alt=""></a></li>
					<li><a href="#" style="opacity: 1;"><img src="style/images/pinterest.png" alt=""></a></li>
				</ul>
			</div>
		</div>
		<div class="f_grid1">
			<ul class="f_nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="clients.html">Projects</a></li>
				<li><a href="clients.html">Staff</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			
			<div class="clear"></div>
		</div>
		<div class="f_logo">
			<div class="copy">
				<p class="w3-link">� 2016<a href="http://w3layouts.com/"> SDCES
</a></p>
			</div>
 		</div>
		<div class="clear"></div>
</div>
</div>
</div>
</body>
</html>