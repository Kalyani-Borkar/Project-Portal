<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<style>
.contact-form select {
    font-family: 'Open Sans', sans-serif;
    color: #333333;
    padding: 8px;
    display: block;
    width: 98%;
    background: rgba(0, 0, 0, 0.21);
    border: 1px solid rgba(0, 0, 0, 0.14);
    outline: none;
    -webkit-appearance: none;
    border-radius: 4px;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    -o-border-radius: 4px;
}
.span_2_of_3 {
    width: 37.1% !important;
   
	padding-top:36px !important;
}
.section.group.uploadform {
    padding-left: 140px;
}
.groupname {
   padding-top:14px !important;
}
</style>
<?php include('layout/header_new.php'); ?>  
<div class="wrap">
	<div class="content">
<div class="section group uploadform">	
				
				<div class="col span_1_of_1">
				<div class="contact-form">
				 <h3>Upload Projects</h3>
					      <form method="post" action="process_upload.php" enctype="multipart/form-data">
					    	<div class="">
						    	<span><label>Group Name</label></span>
						    	<span><input name="group_name" type="text" class="textbox"></span>
						    </div>
							 <div>
						    	<span><label>Domain Used</label></span>
						    	<span><input name="domain_name" type="text" class="textbox"></span>
						    </div>
							<div>
						    	<span><label>Member 1</label></span>
						    	<span><input name="member1" type="text" class="textbox"></span>
						    </div>
							<div>
						    	<span><label>Member 3</label></span>
						    	<span><input name="member3" type="text" class="textbox"></span>
						    </div>
							<div>
						    	<span><label>Member 5</label></span>
						    	<span><input name="member5" type="text" class="textbox"></span>
						    </div>
							 <div>
						    	<span><label>Select Department</label></span>
						    	<select name="field">
								   <option value="COMPUTER ENGINEERING">Select Department </option>
									<option value="COMPUTER ENGINEERING">COMPUTER ENGINEERING </option>
									<option value="MECHANICAL ENGINEERING">MECHANICAL ENGINEERING </option>
									<option value="ELECTRONICS ENGINEERING">ELECTRONICS ENGINEERING </option>
									 <option value="ELECTRONICS AND COMMUNICATION  ENGINEERING">ELECTRONICS AND COMMUNICATION  ENGINEERING</option>
							  </select>
						    </div>
      			 <div class="groupname"><span class="button-wrap"><input type="file" class="text" name="file" ></span><br><br></div>
							</div>
				</div>				
				<div class="col span_2_of_3 ">
				  <div class="contact-form">
				  <div>
						    	<span><label>Project Name</label></span>
						    	<span><input name="project_name" type="text" class="textbox"></span>
						    </div>	
							<div>
						    	<span><label>Project Guide</label></span>
						    	<span><input name="project_guid" type="text" class="textbox"></span>
						    </div>
							
							<div>
						    	<span><label>Member 2</label></span>
						    	<span><input name="member2" type="text" class="textbox"></span>
						    </div>
							
							<div>
						    	<span><label>Member 4</label></span>
						    	<span><input name="member4" type="text" class="textbox"></span>
						    </div>
							
							<div>
						    	<span><label>Member 6</label></span>
						    	<span><input name="member6" type="text" class="textbox"></span>
						    </div>
						   
							 <div>
						    	<span><label>Select Department</label></span>
									<select name="year">
										<option value="2008">2008</option>
										<option value="2009">2009</option>
										<option value="2010">2010</option>
										<option value="2011">2011</option>
										<option value="2012">2012</option>
										<option value="2012">2013</option>
										<option value="2012">2014</option>
										<option value="2012">2015</option>
										<option value="2012">2016</option>
								  </select>
								</div>
						 
							
						   <div class="groupname">
						   		<span class="button-wrap"><input type="submit" value="Submit" name="submit" ></span>
						  </div>
					    </form>
				    </div>
  				</div>	
								
		  </div>
</div>	
</div>
<?php include('layout/footer_new.php'); ?>  