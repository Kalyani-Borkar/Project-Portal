<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 <?php include('layout/header_new.php'); ?> 
<div class="wrap" >
					<!---start-content---->
					<div class="content" >
						<div class="services">
							<h5>Project List</h5>
							<div class="section group">
											
								<table id="t01">
						  <tr>
							<th>Sr. No</th>
							<th>Department Name</th>	
							<th>Project Name</th>	
							<th>Domain Name</th>
							<th>Group Name</th>
							<th>Action</th>	
						  </tr>
						   <?php
	                                   $branch=$_GET['br'];
										$query = "Select * from project where filed='".$branch."' ";
										$res = mysql_query($query);
										$cnt=1;
										while($row= mysql_fetch_array($res))
										{										
									 ?>
						  <tr>
							<td><?php echo $cnt++;	?></td>
							<td><?php echo $row['filed'];?></td>	
							<td><?php echo $row['project_name'];?></td>		
							<td><?php echo $row['domain_name'];?></td>		
							<td><a href="student_project_details.php?group=<?php echo $row['group_name'];?>"><?php echo $row['group_name'];?></a></td>	
							<!--<td><?php echo $row['synopsis'];?></td>	-->
							<td data-toggle="modal" data-target="#myModal"><a href="#">Download</a>
							<!--<a href="download.php?file=<?php echo $row['synopsis'];?>">Download</a>-->
							</td>	
							
						  </tr>
						 <?php }?>
						</table>
							</div>
							
							
							
							<div class="clear"></div>
						</div>
						 </div>
					<!---End-content---->
					<div class="clear" style="padding-top:270px;"> </div>
				</div>
				 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Payment Gateway</h4>
        </div>
        <div class="modal-body">
         <img src="images/payment-gateway.jpg" width="700px" />
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<?php include('layout/footer_new.php'); ?> 
</body>
</html>