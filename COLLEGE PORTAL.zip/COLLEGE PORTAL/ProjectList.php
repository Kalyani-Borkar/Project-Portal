<?php
include('layout/config.php');
error_reporting(0);
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: center;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style></head>
    <?php include('layout/header.php'); ?>   
<!-- banner-slider -->


<!-- about -->
	<div class="about" id="about">
		<div class="container">
			<h3>Project List</h3>
			<div class="about-grids">
				
				<div class="col-md-6 about-grid-left" style="padding-bottom:23%">
					  <table id="t01">
						  <tr>
							<th>Sr. No</th>
							<th>Project Name</th>	
							<th>Group Name</th>
							<th>Action</th>	
						  </tr>
						   <?php
	
										$query = 'Select * from project where filed="'.$_GET['br'].'"';
										$res = mysql_query($query);
										$cnt=1;
										while($row= mysql_fetch_array($res))
										{										
									 ?>
						  <tr>
							<td><?php echo $cnt++;	?></td>
							<td><?php echo $row['project_name'];?></td>		
							<td><?php echo $row['group_name'];?></td>	
							<!--<td><?php echo $row['synopsis'];?></td>	-->
							<td><a href="download.php/file=<?php echo $row['synopsis'];?>">Download</a></td>	
							
						  </tr>
						 <?php }?>
						</table>
					
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //about -->
<!-- services -->


	

<!-- //contact -->
<div id="footer-container">
    <?php include('layout/footer.php'); ?>
</div>
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body>
</html>
<!--http://stanhub.com/create-responsive-popup-modal-window-jquery-no-plugin/-->