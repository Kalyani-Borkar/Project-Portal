<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<style>
.contact-form select {
    font-family: 'Open Sans', sans-serif;
    color: #333333;
    padding: 8px;
    display: block;
    width: 98%;
    background: rgba(0, 0, 0, 0.21);
    border: 1px solid rgba(0, 0, 0, 0.14);
    outline: none;
    -webkit-appearance: none;
    border-radius: 4px;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    -o-border-radius: 4px;
}
.span_2_of_3 {
    width: 37.1% !important;
   
	padding-top:36px !important;
}
.section.group.uploadform {
    padding-left: 140px;
}
.groupname {
   padding-top:14px !important;
}
</style>
<?php include('layout/header_new.php'); ?>  

<div class="wrap" style="padding-bottom:150px;">
	<div class="content">
<div class="section group uploadform">	
				<?php
	
										$query = "Select * from tbl_register where id='".$_SESSION['id']."'";
										$res = mysql_query($query);
										
										if($row= mysql_fetch_array($res))
										{										
									 ?>
				<div class="col span_1_of_2" style="width:300px;">
				<div class="contact-form">
				 <h3>My Profile</h3>
					      <form method="post" action="process_change.php" enctype="multipart/form-data">
						  <input name="id" type="hidden" class="textbox" value="<?php echo $row['id'];?>" readonly>
					    	<div class="">
						    	<span><label>Email</label></span>
						    	<span><input name="email" type="text" class="textbox"  ></span>
						    </div>
							 <div>
						    	<span><label>Old Password</label></span>
						    	<span><input name="oldpwd" type="text" class="textbox" ></span>
						    </div>
							
							<div>
						    	<span><label>New Password</label></span>
						    	<span><input name="newpwd" type="text" class="textbox"></span>
						    </div>
							
      			  <div class="groupname">
						   		<span class="button-wrap"><input type="submit" value="Submit" name="submit" ></span>
						  </div>
						</form>	
				</div>				
					
				<?php } ?>		
					</div>	
		  </div>
</div>	
</div>
<?php include('layout/footer_new.php'); ?>  