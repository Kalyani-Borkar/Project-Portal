<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
 <?php include('layout/header_new.php'); ?>  
<div class="wrap" style="padding-bottom:117px;">
					<!---start-content---->
					<div class="content" style="height:220px;">
						<div class="services">
							<h5>Dashboard</h5>
							<div class="section group" style="vertical-align:middle;padding-top:50px;">
								<div class="listview_1_of_2 images_1_of_2" style="margin-top:-13px;">
									
								    <div class="text list_2_of_1" style="text-align:right">
									<a href="student_project_department.php"><h3>View Projects</h3></a>
										
										
								   </div>
							   </div>			
								<div class="listview_1_of_2 images_1_of_1" style="width:200px;">
									
								    <div class="text list_2_of_1" style="text-align:left">
										 <a href="upload.php"><h3>Upload Project</h3></a>
										
										
								   </div>
							   </div>
							   <div class="listview_1_of_2 images_1_of_1" style="width:200px;">
									
								    <div class="text list_2_of_1" style="text-align:right">
										 <a href="admin_profile_new.php"><h3>My Profile</h3></a>
										
										
								   </div>
							   </div>
							</div>
							
							
							
							<div class="clear"></div>
						</div>
						 </div>
					<!---End-content---->
					<div class="clear"> </div>
				</div>
<?php include('layout/footer_new.php'); ?>  
</body>
</html>