<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style>
 <?php include('layout/header_new.php'); ?> 
<div class="wrap" style="padding-bottom:170px;">
					<!---start-content---->
					<div class="content">
						<div class="services">
							<h5>Project Details</h5>
							<div class="section group">
											
								<table id="t01">
						  <tr>
							<th>Sr. No</th>
							<th>Department Name</th>	
							<th>Project Name</th>	
							<th>Domain Name</th>	
							<th>Group Name</th>
							<th>Group Member's Name</th>
							<th>Project Guide</th>
							<th>Action</th>	
						  </tr>
						   <?php
	
										$query = "Select * from project where group_name='".$_GET['group']."'";
										$res = mysql_query($query);
										$cnt=1;
										while($row= mysql_fetch_array($res))
										{										
									 ?>
						  <tr>
							<td><?php echo $cnt++;	?></td>
							<td><?php echo $row['filed'];?></td>	
							<td><?php echo $row['project_name'];?></td>		
							<td><?php echo $row['domain_name'];?></td>	
							<td><?php echo $row['group_name'];?></td>
							<td><table id="t01"><tr><td>1. </td><td><?php echo $row['project_member1'];?></td></tr>
							<tr><td>2. </td><td><?php echo $row['project_member2'];?></td></tr>
							<tr><td>3. </td><td><?php echo $row['project_member3'];?></td></tr>
							<tr><td>4. </td><td><?php echo $row['project_member4'];?></td></tr>
							<tr><td>5. </td><td><?php echo $row['project_member5'];?></td></tr>
							<tr><td>6. </td><td><?php echo $row['project_member6'];?></td></tr></table></td>
							<td><?php echo $row['project_guid'];?></td>		
							<td>
							<a href="download.php?file=<?php echo $row['synopsis'];?>">Download</a>
							</td>	
							
						  </tr>
						 <?php }?>
						</table>
							</div>
							
							
							
							<div class="clear"></div>
						</div>
						 </div>
					<!---End-content---->
					<div class="clear"> </div>
				</div>
<?php include('layout/footer_new.php'); ?> 
</body>
</html>