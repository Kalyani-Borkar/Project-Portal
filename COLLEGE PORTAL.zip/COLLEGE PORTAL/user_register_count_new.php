<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style>
 <?php include('layout/header_new.php'); ?> 
<div class="wrap" style="padding-bottom:210px;">
					<!---start-content---->
					<div class="content" >
						<div class="services">
							<h5>Staff List</h5>
							<div class="section group">
											
								<table id="t01">
						  <tr>
							<th>Sr. No</th>
							<th>Name</th>	
							<th>User Id</th>
							<th>Type</th>	
							<th>Action</th>	
						  </tr>
						   <?php
	
										$query = 'Select * from tbl_register where type != "Admin" and type="staff" ';
										$res = mysql_query($query);
										$cnt=1;
										while($row= mysql_fetch_array($res))
										{										
									 ?>
						  <tr>
							<td><?php echo $cnt++;	?></td>
							<td><?php echo $row['f_name']."  ".$row['l_name'];?></td>		
							<td><?php echo $row['clg_id'];?></td>	
							<td><?php echo $row['type'];?></td>	
							<td><a href="delete_staff.php?id=<?php echo $row['id'];?>">Delete</a><br>
							<a href="create_staff.php?id=<?php echo $row['id'];?>">Create Id</a></td>	
							
						  </tr>
						 <?php }?>
						</table>
							</div>
							<?php
				$query1 ='Select COUNT(id) AS "total" from tbl_register where type != "Admin" and type="staff"';
				$result=mysql_query($query1);
				if($row1=mysql_fetch_assoc($result))
				{ $total1=$row1['total'];
}

?>
				<div class=""><br> <h5>Total User Count: <?php echo $total1; ?> </h5></div>
							
							
							<div class="clear"></div>
						</div>
						 </div>
					<!---End-content---->
					<div class="clear"> </div>
				</div>
<?php include('layout/footer_new.php'); ?> 
</body>
</html>