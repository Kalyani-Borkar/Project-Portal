-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 09, 2017 at 02:37 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_wardha`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` varchar(70) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `branch`) VALUES
(1, 'COMPUTER ENGINEERING\r\n'),
(2, 'MECHANICAL ENGINEERING'),
(3, 'ELECTRONICS ENGINEERING'),
(4, 'ELECTRONICS AND COMMUNICATION  ENGINEERING\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(150) NOT NULL,
  `group_name` varchar(50) NOT NULL,
  `filed` varchar(100) NOT NULL,
  `year` varchar(6) NOT NULL,
  `project_guid` varchar(150) NOT NULL,
  `project_member1` varchar(100) NOT NULL,
  `project_member2` varchar(100) NOT NULL,
  `project_member3` varchar(100) NOT NULL,
  `project_member4` varchar(100) NOT NULL,
  `project_member5` varchar(100) NOT NULL,
  `project_member6` varchar(30) NOT NULL,
  `project_member7` varchar(150) NOT NULL,
  `domain_name` varchar(150) NOT NULL,
  `synopsis` text NOT NULL,
  `thesis` text NOT NULL,
  `created` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `project_name`, `group_name`, `filed`, `year`, `project_guid`, `project_member1`, `project_member2`, `project_member3`, `project_member4`, `project_member5`, `project_member6`, `project_member7`, `domain_name`, `synopsis`, `thesis`, `created`) VALUES
(3, 'Wardha College', 'WardhaGroup', 'ELECTRONICS ENGINEERING', '2009', 'Bharti', ' none', 'A2', 'A3', 'A4', 'A5', 'A6', '', '', 'theme links.txt', '', '2016-01-14'),
(4, 'Akash Idea', 'Akash', 'COMPUTER ENGINEERING', '2012', 'Pipal', 'Varun', 'Tarun', 'Arun', 'Rahun', 'Swarun', 'Pahun', '', '', 'Hello.docx', '', '2016-01-14'),
(5, 'Akash Idea', 'Akash', 'MECHANICAL ENGINEERING', '2012', 'Pipal', 'Varun', 'Tarun', 'Arun', 'Rahun', 'Swarun', 'Pahun', '', '', 'Hello.docx', '', '2016-01-14'),
(8, 'Upload Files', 'NewerTall', 'ELECTRONICS ENGINEERING', '2011', 'Topper', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', '', '', 'Hello.docx', '', '2016-01-15'),
(10, 'Dheerva', 'Dheerva', 'ELECTRONICS ENGINEERING', '2010', 'Mrs. Ranu', 'M1', 'M2', 'M3', 'M4', 'M5', 'M6', '', '', 'file/demo.docx', '', '2016-01-15'),
(12, 'hawda bridge', 'Dadar hawelo', 'ELECTRONICS ENGINEERING', '2010', 'kkk', 'meme', 'mememe', 'memememe', 'mememememe', 'memememememe', 'memememememememe', '', '', 'file/index.html', '', '2016-02-27'),
(14, 'MI Mobile', 'MI', 'ELECTRONICS ENGINEERING', '2009', 'Asa', 'L', 'Lq', 'l2', 'l3l', 'l5', 'l9', '', '', 'file/1656.jpg', '', '2016-03-13'),
(16, 'KKK', 'ABC', 'ELECTRONICS AND COMMUNICATION  ENGINEERING', '2012', 'Oma', 'ak', 'ak2', 'ak3', 'ak4', 'ak5', 'ak6', '', 'Redar', 'file/zp1.JPG', '', '2016-03-13'),
(17, 'test project', 'Test', 'COMPUTER ENGINEERING', '2012', 'M', 'abc', 'def', 'ghi', 'jkl', 'mno', 'pqr', 'stu', 'testing', 'file/db_wardha (3).sql', '', '2007-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register`
--

CREATE TABLE IF NOT EXISTS `tbl_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(30) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `clg_id` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `type` varchar(30) NOT NULL,
  `createdDate` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_register`
--

INSERT INTO `tbl_register` (`id`, `f_name`, `l_name`, `clg_id`, `email`, `password`, `phone`, `type`, `createdDate`) VALUES
(4, 'Aarti', 'Murkute', 'a123', 'aarti@gmail.com', 'aarti12345', '1232321231', 'Admin', '2016-01-10'),
(9, 'Diya', 'Ket', 'E12345', 'diya@gmail.com', 'diya123', '2323232323', 'Staff', ''),
(12, 'Anush', 'Thapar', 'E12346', 'anusha@gmail.com', 'anusha123', '2323232323', 'Staff', ''),
(13, 'Bharti ', 'S', 'SF123', 'bharti@gmail.com', 'bharti000', '3434343434', 'Final Year Student', ''),
(14, 'Suchita', 'Rai', 'S123', 'suchita@gmail.com', 'suchi123', '4545454545', 'In Student', ''),
(15, 'Arun', 'Kalpana', 'k123', 'kalpana_arun@gmail.com', 'kalpanaarun', '9483548754', 'Guest Student', '');
