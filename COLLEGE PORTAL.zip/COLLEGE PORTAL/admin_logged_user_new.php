<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<style>
.full-circle {
       background-color: #F2980F;
    height: 50px;
    width: 50px;
    -webkit-border-radius: 75px;
    -moz-border-radius: 75px;
    color: #fff !important;
	line-height:46px;
}
</style>
 <?php include('layout/header_new.php'); ?>  
<div class="wrap" style="padding-bottom:117px;">
					<!---start-content---->
					<div class="content" style="height:220px;">
						<div class="services">
							<h5>Online Users</h5>
							<div class="section group" style="vertical-align:middle;padding-top:50px;">
								<div class="listview_1_of_2 images_1_of_2">
									<div class="listimg listimg_2_of_1">
										 
									</div>
								    <div class="text list_2_of_1" style="text-align:center">
										<a href="user_register_count_new.php"><h3>Logged User</h3></a>
										
										<div class="btn">
											<!--<span class="button-wrap"><a href="details.html" class="button button-pill ">Read Me</a></span>-->
										</div>
								   </div>
							   </div>			
								<div class="listview_1_of_2 images_1_of_2">
									<div class="listimg listimg_2_of_1">
										 
									</div>
								    <div class="text list_2_of_1" style="text-align:center">
										 <a href="user_register_count_stud_new.php"><h3 class="full-circle">1</h3></a>
										
										<div class="btn">
											<!--<span class="button-wrap"><a href="details.html" class="button button-pill ">Read Me</a></span>-->
										</div>
								   </div>
							   </div>
							</div>
						
							
							
							<div class="clear"></div>
						</div>
						 </div>
					<!---End-content---->
					<div class="clear"> </div>
				</div>
<?php include('layout/footer_new.php'); ?>  
</body>
</html>