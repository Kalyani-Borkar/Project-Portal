<?php
include('layout/config.php');

$iid=$_GET['id'];
$mem1=$_GET['mem1'];
$mem2=$_GET['mem2'];
$mem3=$_GET['mem3'];
$mem4=$_GET['mem4'];
$mem5=$_GET['mem5'];
$mem6=$_GET['mem6'];
				//$query='delete from project where id="'.$iid.'"';
              	
	$query='UPDATE project SET project_member1 = "none" where id="'.$iid.'" and project_member1 = "'.$mem1.'" ';
	
	//echo $query;
			if(mysql_query($query))
			{		
					echo " <script> alert('Sucessfully Deleted')</script>";
					header("location:adminlist_new.php");
				
				}
			
			else
			{
				echo mysql_error();}
				

?>