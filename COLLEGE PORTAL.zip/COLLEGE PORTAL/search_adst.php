<?php
// Array with names
 include('layout/config.php'); 

$in=$_GET['txt'];
if(!ctype_alnum($in)){
echo "Data Error";
exit;
}

	
										 //$branch=$_GET['br'];
									/*	$query = "Select * from project where filed='".$branch."' ";
										$res = mysql_query($query);
										$cnt=1;
										while($row= mysql_fetch_array($res))
										{				*/						
									
$msg="";
$msg="<select id=s1 size='15'>";
if(strlen($in)>0 and strlen($in) <20 ){
$sql="Select * from project where project_name='".$in."'";
foreach ($dbo->query($sql) as $nt) {
//$msg.=$nt[name]."->$nt[id]<br>";
$msg .="<table id="t01">
						  <tr>
							<th>Sr. No</th>
							<th>Department Name</th>	
							<th>Project Name</th>
							<th>Domain Name</th>	
							<th>Group Name</th>
							<th>Action</th>	
						  </tr>
						  
						  <tr>
							<td><?php echo $cnt++;	?></td>
							<td><?php echo $row['filed'];?></td>	
							<td><?php echo $row['project_name'];?></td>	
							<td><?php echo $row['domain_name'];?></td>		
							<td><a href="projectDetails_new.php?group=echo $row['group_name'];"> echo $row['group_name'];</a></td>	
							<!--<td><?php echo $row['synopsis'];?></td>	-->
							<td><a href="delete_admin.php?id= echo $row['id'];">Delete</a><br>
							<a href="download.php?file= echo $row['synopsis'];">Download</a>
							</td>	
							
						  </tr>
						
						</table>";
//$msg .="<option value='$nt[name]'>";

}
}
$msg .='</select>';
echo $msg;
?>