<?php
include('layout/config.php');

if (isset($_POST["submit"])) {
$iid=$_POST['id'];
$staff_id=$_POST['staff_id'];
$l_name=$_POST['l_name'];
$f_name=$_POST['f_name'];
$emailid=$_POST['email'];
$phone=$_POST['phone'];
				//$query='delete from tbl_register where id="'.$iid.'" and type="staff"';
             //UPDATE table_name SET column1=value, column2=value2,...  WHERE some_column=some_value 
$query=" UPDATE tbl_register SET f_name='".$f_name."', l_name='".$l_name."', clg_id='".$staff_id."', email='".$emailid."', phone='".$phone."' WHERE id='".$iid."' ";
	
	
	//echo $query;
			if(mysql_query($query))
			{		
					echo " <script> alert('Sucessfully Updated')</script>";
					header("location:admin_profile_new.php");
				
				}
			
			else
			{
				echo mysql_error();}
				
				
}

?>