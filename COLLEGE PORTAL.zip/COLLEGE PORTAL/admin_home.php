<?php
include('layout/config.php');
error_reporting(0);
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style></head>
    <?php include('layout/headerAdmin.php'); ?>   
<!-- banner-slider -->


<!-- about -->
	<div class="about" id="about" style="padding-bottom:23%">
		<div class="container">
			<h3>Management Status</h3><hr color="#66CCCC">
			<div class="about-grids">
				
				<div class="col-md-6" style="text-align:right">
				
					<a href="admin_section.php"> <h1>Admin Section</h1></a>
							
					
				</div>
				<div class="col-md-6 about-grid-left">
				
					 <a href="department_admin.php"><h1>Department</h1></a>
							
					
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //about -->
<!-- services -->


	

<!-- //contact -->
<div id="footer-container" >
    <?php include('layout/footer.php'); ?>
</div>
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body>
</html>