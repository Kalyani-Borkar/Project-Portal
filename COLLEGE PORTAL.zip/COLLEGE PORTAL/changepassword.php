<?php
include('layout/config.php');
error_reporting(0);
 ?>
<!DOCTYPE html>
<html>
<head>
<title>Arts School a Educational Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<!--fonts-->
<style>
.contact-top-right form input[type="password"] {
    width: 49%;
    color: #555;
    outline: none;
    font-size: 0.9em;
    padding: 13px 13px;
    margin-bottom: 1em;
    border: solid 1px #9cd8d8;
    -webkit-appearance: none;
   
}
</style>
   <?php include('layout/header.php'); ?>   
<!-- banner-slider -->
<!--//end-teachers-->
<!-- //team -->
<!-- gallery -->
<!-- //gallery -->
<!-- contact -->
<div class="contact" id="contact">
  <div class="container">
    <h3 class="tittle two">Change Password</h3>
    <div class="contact-top">
	<div class="col-md-3"></div>
      <div class="col-md-6 contact-top-right">
        <form method="post" action="process_change.php" enctype="multipart/form-data">
		<div>
          <input type="text" class="" placeholder="Username/ Email Id" name="email" required ><br>
        </div><div>
          <input type="password" class="" placeholder="Old Password" name="oldpwd" required><br>
         </div><div>
          <input type="password" class="" placeholder="New Password" name="newpwd" reuired pattern="[a-zA-Z]*[0-9]*"><br>
         </div>
          <div class="sub-button">
            <input type="submit" value="Submit" name="submit">
          </div>
        </form>
      </div>
	  <div class="col-md-2"></div>
      <div class="clearfix"> </div>
    </div>
  </div>
</div>
<!-- //contact -->
<div class="copy-right">
  <div class="container">
    <?php include('layout/footer.php'); ?>
  </div>
</div>
<!-- smooth scrolling -->
<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body></html>
