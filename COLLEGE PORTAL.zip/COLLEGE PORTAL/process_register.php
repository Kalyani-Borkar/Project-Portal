<?php
include('layout/config.php');

if (isset($_POST["create"])) {
				$name=$_POST['fname'];
				$email=$_POST['email'];
				$password=$_POST['password'];
				$phone=$_POST['phone'];
				$lname=$_POST['lname'];
				$type=$_POST['type'];
				$seid=$_POST['seid'];
				/*$dat=date('Y-m-d');*/
				$query='insert into tbl_register set f_name="'.$name.'",l_name="'.$lname.'",clg_id="'.$seid.'",email="'.$email.'",
				password="'.$password.'",phone="'.$phone.'",type="'.$type.'"';
              	
	
	
	//echo $query;
			if(mysql_query($query))
			{		
					echo " Sucess Fully Inserted";
					header("location:login.php");
				
				}
			
			else
			{
				echo mysql_error();}
				
}
?>