<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head></head>
<?php include('layout/header.php'); error_reporting(0);?>   

<!-- //welcome -->
<!-- about -->
	
<!-- //about -->
<!-- services -->
<div id="services" class="services1">
	<div class="container">
		
			<div class="servc-grids banner-info">
			
				<center>
				<h2>Welcome Student</h2>
					<a href="upload.php"><h4>Click here to upload your project</h4></a></center>
				
				<div class="clearfix"> </div>
			</div>
	</div>
</div>
<!-- services -->
<!-- team -->
<!--start-teachers-->


   <!--//end-teachers-->
<!-- //team -->
<!-- gallery -->

<!-- //gallery -->
<!-- contact -->
	

<!-- //contact -->
<div class="copy-right">
	<div class="container">
		<?php include('layout/footer.php'); ?>
	</div>
</div>
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body>
</html>