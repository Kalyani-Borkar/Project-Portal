<?php
include('layout/config.php');

$iid=$_GET['id'];
				$query='delete from tbl_register where id="'.$iid.'";
              	
	
	
	//echo $query;
			if(mysql_query($query))
			{		
					echo " <script> alert('Sucessfully Deleted')</script>";
					header("location:user_register_count_stud_new.php");
				
				}
			
			else
			{
				echo mysql_error();}
				

?>