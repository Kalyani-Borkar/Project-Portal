<?php

require_once('layout/config.php');
session_destroy();
header("Location:index.php");
exit;

?>