<?php 

$ebits = ini_get('error_reporting');
error_reporting($ebits ^ E_NOTICE);

include_once("layout/config.php");
if (isset($_POST["login"])) {
			
        $username=$_POST['username'];
			$password=$_POST['password'];
	
			$query="SELECT * FROM tbl_register WHERE email='$username' AND  password='$password'";
	
			$res = mysql_query($query) or die("wrong query");
	
			$row = mysql_fetch_assoc($res);	
			
		if(!empty($row))
		{
			if($_POST['password']==$row['password'])
			{
				//login
				$_SESSION = array();
				
				$_SESSION['id']=$row['id'];
				if ($row['type'] == "Final Year Student" ) {
						header("location: finalyear_home.php");exit();
					}
					if ($row['type'] == "Admin" ) {
							header("location: admin_home_new.php");exit();
					}
					if ($row['type'] == "Staff" ) {
							header("location: staff_home.php");exit();
					}
					if ($row['type'] == "Guest Student" ) {
							header("location: guest_home.php");exit();
					}
					if ($row['type'] == "In Student" ) {
							header("location: student_home.php");exit();
					}
				//$_SESSION['first_name']=$row['first_name'];
				
				
			}
			else
			{
				echo "Wrong Password";
			}
		}
		else
		{
			echo "No Such User";
		}
            
	}