<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

    <?php include('layout/header_new.php'); ?>  
<div class="fluid_container">
        <div class="camera_wrap camera_azure_skin" id="camera_wrap_1">
            <div  data-src="style/images/slider1.jpg">
            </div>
            <div data-src="style/images/slider2.jpg">
            </div>
            <div  data-src="style/images/slider3.jpg">
            </div>
        </div><!-- #camera_wrap_1 -->
   </div><!-- .fluid_container -->
<?php include('layout/footer_new.php'); ?>  