<?php 
$conn=mysql_connect('localhost','root','') or die("server not found");
mysql_select_db('db_wardha') or die("could not connect with database");


session_name('Auth');

session_start();

?>
