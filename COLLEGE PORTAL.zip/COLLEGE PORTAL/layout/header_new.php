<?php include('layout/config.php'); ?>
<!DOCTYPE HTML>
<html>
<head>
<title>The Knowledge Website Template | Home :: w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link href="style/css/style.css" rel="stylesheet" type="text/css" media="all" />
<script src='style/js/jquery-1.8.1.min.js' type='text/javascript'></script>
<script src='style/js/jquery.kwicks.js' type='text/javascript'></script>
<script type='text/javascript'>
	$(function() {
	$('.kwicks').kwicks({
		maxSize : 250,
		spacing : 5,
		behavior: 'menu'
		});
	});
</script>
 <link rel='stylesheet' id='camera-css'  href='style/css/camera.css' type='text/css' media='all'> 
<!-- Scripts--> 
    <script type='text/javascript' src='style/js/jquery.min.js'></script>
    <script type='text/javascript' src='style/js/jquery.mobile.customized.min.js'></script>
    <script type='text/javascript' src='style/js/jquery.easing.1.3.js'></script> 
    <script type='text/javascript' src='style/js/camera.min.js'></script> 
    <script>
		jQuery(function(){
			
			jQuery('#camera_wrap_1').camera({
				thumbnails: true
			});

			jQuery('#camera_wrap_2').camera({
				height: '400px',
				loader: 'bar',
				pagination: false,
				thumbnails: true
			});
		});
	</script>
</head>
<body>
<div class="header-bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
		  		<a href="index.html"><img src="style/images/logo1.png"> </a>
		 </div>
		<div class="menu">
			<ul class='kwicks kwicks-horizontal'>
			<?php if(empty($_SESSION['id'])){?>
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="clients.html">Projects</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="login.php">Login</a></li>
				 <?php }else{ ?>	
				 <li class="active"><a href="index.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="clients.html">Projects</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="logout.php">Logout</a></li>
				 <?php } ?>			
			</ul>
	 </div>
	 <div class="clear"></div>
	</div>
</div>
</div>
