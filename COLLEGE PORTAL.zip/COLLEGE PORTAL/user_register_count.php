<?php
include('layout/config.php');
error_reporting(0);
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
</style></head>
    <?php include('layout/headerAdmin.php'); ?>   
<!-- banner-slider -->


<!-- about -->
	<div class="about" id="about">
		<div class="container">
			<h3>Project List</h3>
			<div class="about-grids" style="padding-bottom:20%">
				
				<div class="col-md-6 about-grid-left">
					  <table id="t01">
						  <tr>
							<th>Sr. No</th>
							<th>Name</th>	
							<th>User Id</th>
							<th>Type</th>	
						  </tr>
						   <?php
	
										$query = 'Select * from tbl_register where type != "Admin" ';
										$res = mysql_query($query);
										$cnt=1;
										while($row= mysql_fetch_array($res))
										{										
									 ?>
						  <tr>
							<td><?php echo $cnt++;	?></td>
							<td><?php echo $row['f_name']."  ".$row['l_name'];?></td>		
							<td><?php echo $row['clg_id'];?></td>	
							<td><?php echo $row['type'];?></td>	
							
							
						  </tr>
						 <?php }?>
						</table>
					<?php
				$query1 ='Select COUNT(id) AS "total" from tbl_register where type != "Admin"';
				$result=mysql_query($query1);
				if($row1=mysql_fetch_assoc($result))
				{ $total1=$row1['total'];
}

?>
				<div class=""><br> <h5>Total User Count: <?php echo $total1; ?> </h5></div>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //about -->
<!-- services -->


	

<!-- //contact -->
<div id="footer-container">
    <?php include('layout/footer.php'); ?>
</div>
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body>
</html>